<CENTER>
<table border="1px" width="70%" cellpadding="5" cellspacing="0">
<tr>
	<th>No :</th>
	<th>Nama :</th>
	<th>Jabatan</th>
	<th>NO Hp:</th>
</tr>
<tr>
	<td>1.</td>
	<td>LODIANSAH</td>
	<td>DIREKTUR UTAMA</td>
	<td>085368778684</td>
</tr>
<tr>
	<td>2.</td>
	<td>RYO PERDINAN</td>
	<td>WAKIL DIREKTUR</td>
	<td>089837263827</td>
</tr>
<tr>
	<td>3.</td>
	<td>MELISA S</td>
	<td>SEKRETARIS</td>
	<td>087674287678</td>
</tr>
<tr>
	<td>3.</td>
	<td>CITA LOLANDIA</td>
	<td>BENDAHARA</td>
	<td>0858598989</td>
</tr>

 </table>
</CENTER>